#include "pool.h"

Task::Task() 
{
    pthread_cond_init(&cv, NULL);
    finished = false;
}

Task::~Task() 
{

}

ThreadPool::ThreadPool(int num_threads) // create the threads used in the assignment
{
    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&task_ready, NULL);

    this->num_threads = num_threads;

    ThreadInfo * info = new ThreadInfo();
    info->lock = &this->lock;
    info->task_ready = &this->task_ready;

    info->buffer = &this->buffer;
    //info.taskMap = &this->taskMap;
    info->finished = &this->finished;
    this->info = info;


    pthread_t* threadArr;
    threadArr = new pthread_t[num_threads];
    this->threadArr = threadArr;

    for(int i = 0; i < num_threads; ++i)
    {
        //cout << "a" << endl;
        pthread_create(&threadArr[i], NULL, Consume, info);
    }

}

void ThreadPool::SubmitTask(const std::string &name, Task* task) // produce
{
    // check if finished ??
    if (!finished)
    {
        //cout << "g" << endl;
        pthread_mutex_lock(&lock);
        //cout << "h" << endl;
        buffer.push_back(task); // pair not task    
        taskMap.insert(pair<string, Task*>(name, task));
        pthread_cond_signal(&task_ready);
        //cout << "i" << endl;
        pthread_mutex_unlock(&lock);        
    }
}
void* ThreadPool::Consume(void* args) 
{ 
    ThreadInfo* my_info = (ThreadInfo*) args;
    pthread_mutex_t* lock_c = my_info->lock;
    pthread_cond_t* task_ready_c = my_info->task_ready;

    deque<Task*>* buffer_c = my_info->buffer;
    //map<string,Task*>* taskMap_c = my_info->taskMap;
    bool* finished_c = my_info->finished;
    //cout << "b" << endl; 

    while(true)
    {
        //lock
        //cout << "c" << endl;
        if(*finished_c)
        {
            break;
        }
        pthread_mutex_lock(lock_c);
        while(buffer_c->empty() && !(*finished_c) )
        {
            //cout << "e" << endl;
            pthread_cond_wait(task_ready_c, lock_c);
            //cout << "f" << endl; 
        }
            //cout << "f" << endl;

            // deque from the buffer
        if( !buffer_c->empty() )
        {
            Task* task = buffer_c->front(); // pair not task?
            buffer_c->pop_front();
            pthread_mutex_unlock(lock_c);
            task->Run();
            pthread_mutex_lock(lock_c);
            task->finished = true;
            pthread_cond_broadcast(&task->cv);
            //delete task;
            //task = NULL;
        }
        pthread_mutex_unlock(lock_c);
            //unlock

    }
    // pthread_mutex_lock(lock_c);
    // while(!buffer_c->empty())
    // {
    //     pthread_mutex_lock(lock_c);
    //     Task* task = buffer_c->front(); // pair not task?
    //     buffer_c->pop_front();
    //     pthread_mutex_unlock(lock_c);

    //     task->Run();
    //     task->finished = true;
    //     pthread_cond_broadcast(&task->cv);
    //     //delete task;
    //     //task = NULL;
    // }
    // pthread_mutex_unlock(lock_c);
    return NULL;
}
void ThreadPool::WaitForTask(const std::string &name) // consume??
{
    pthread_mutex_lock(&lock);
    Task* task = taskMap.at(name);
    if(!task->finished)
    {
        //pthread_mutex_lock(&lock);
        //pthread_mutex_lock(&lock);
        while(!task->finished) // check if name is in the set
        {
            pthread_cond_wait(&task->cv, &lock); // unlock of unlocked mutex
        }
        //pthread_mutex_unlock(&lock);
    }
    pthread_mutex_unlock(&lock);
}


void ThreadPool::Stop() 
{
    pthread_mutex_lock(&lock);
    finished = true;
    pthread_mutex_unlock(&lock);

    pthread_cond_broadcast(&task_ready);
    for(int i = 0; i < num_threads; ++i)
    {
        pthread_join(threadArr[i], NULL);
    }

    // free task memory
    for ( auto it = taskMap.begin(); it != taskMap.end(); ++it  )
    {
       delete it->second;
       it->second = NULL;
    } 
    delete[] threadArr;
    delete info;   
}


// void* ThreadPool::ThreadRun(void* args) 
// { 
//     ThreadInfo* my_info = (ThreadInfo*) args;
//     Task* task = my_info->task_info;
//     task->Run();
//     task->finished = true;
//     pthread_cond_signal(&task->cv);
//     return NULL;
// }