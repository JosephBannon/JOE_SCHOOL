#ifndef POOL_H_
#include <string>
#include <pthread.h>
#include <deque>
#include <map>
#include <algorithm>
#include <iostream>


using namespace std;



class Task {
public:
    Task();
    virtual ~Task();

    virtual void Run() = 0;  // implemented by subclass

    bool finished = false;
    pthread_cond_t cv;
};

struct ThreadInfo 
{
    pthread_mutex_t* lock;
    pthread_cond_t* task_ready;

    deque<Task*>* buffer;
    map<string,Task*>* taskMap;
    bool* finished;
    //string name;
};

class ThreadPool {
public:
    ThreadPool(int num_threads);

    // Submit a task with a particular name.
    void SubmitTask(const std::string &name, Task *task);
 
    // Wait for a task by name, if it hasn't been waited for yet. Only returns after the task is completed.
    void WaitForTask(const std::string &name);

    // Stop all threads. All tasks must have been waited for before calling this.
    // You may assume that SubmitTask() is not caled after this is called.
    void Stop();

    static void* Consume(void* args);



    pthread_mutex_t lock;
    pthread_cond_t task_ready;

    deque<Task*> buffer;
    map<string,Task*> taskMap;
    pthread_t* threadArr;
    ThreadInfo* info; 
    int num_threads;
    bool finished = false;

};
#endif
