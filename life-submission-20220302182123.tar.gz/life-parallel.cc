#include "life.h"
#include <pthread.h>
#include <iostream>

using namespace std;

// equal work for each threads
// no complex complications in each cell
// sanitizing
// speed up for large boards


struct ThreadInfo {
LifeBoard* state;
LifeBoard* next_state;
int steps;
int threads;
int section;
pthread_barrier_t* barrier;
};

void *run(void *args);
void runEvenOdd(LifeBoard *, LifeBoard *, int, int, int);

void simulate_life_parallel(int threads, LifeBoard &state, int steps) 
{
    LifeBoard next_state{state.width(), state.height()};
    ThreadInfo *info;
    info = new ThreadInfo[threads];

    pthread_t* threadArr;
    threadArr = new pthread_t[threads];
    pthread_barrier_t barrier;
    pthread_barrier_init( &barrier, NULL, threads);
    for(int i = 0; i < threads; ++i)
    {

        info[i].state = &state;
        info[i].next_state = &next_state;
        info[i].steps = steps;
        info[i].threads = threads;
        info[i].section = i;
        info[i].barrier = &barrier;
        pthread_create(&threadArr[i], NULL, run, (void*) &info[i]);
    }

    for(int i = 0; i < threads; ++i)
        pthread_join(threadArr[i], NULL);

    delete[] threadArr;
    delete[] info;
    // wait
    pthread_barrier_destroy(&barrier);
}

int divide(long long dividend, long long divisor) {
 
  long long quotient = 0, temp = 0;
 

  for (int i = 31; i >= 0; --i) {
 
    if (temp + (divisor << i) <= dividend) {
      temp += divisor << i;
      quotient |= 1LL << i;
    }
  }

   
  return quotient;
  /* Algorithm for faster division without mul or div
  Source: https://www.geeksforgeeks.org/divide-two-integers-without-using-multiplication-division-mod-operator/
  */
}
void *run(void *args)
{
    ThreadInfo* my_info = (ThreadInfo*) args;
    int steps = my_info->steps;
    int threads = my_info->threads;
    int section = my_info->section;
    LifeBoard* state = my_info->state;
    LifeBoard* next_state = my_info->next_state;
    pthread_barrier_t* barrier = my_info->barrier;
    //int count = 0;

    int h = state->height();
    //int w = state->width();
    // check if is power of 2
    int startY =   (section * (h - 1) / threads)  + 1;
    int endY =  ((section+1) * (h - 1) / threads);
    for (int step = 0; step < steps; ++step) 
    {
        /* We use the range [1, width - 1) here instead of
         * [0, width) because we fix the edges to be all 0s.
         */
        if (step % 2 == 0) // is even
        {
            runEvenOdd(state, next_state, startY, endY, h);
            //cout << "even" << endl;
        }
        else // is odd
        {
            runEvenOdd(next_state, state, startY, endY, h);
            //cout << "odd" << endl;
        }
        pthread_barrier_wait(barrier);
        /* now that we computed next_state, make it the current state */
    }
    if(steps % 2 == 1 && section == 0)
    {
        //cout << "f" << endl;
        swap(*state, *next_state);
    }
    return NULL;
    
}

void runEvenOdd(LifeBoard* state, LifeBoard* next_state, int startY, int endY, int h)
{

    for (int y = startY; y <= endY && y < h - 1; ++y) 
    {
            //int count = 0;
            //cout << y << endl;
        for (int x = 1; x < state->width() - 1; ++x) 
        {
                //cout << x  << endl;
            int live_in_window = 0;
                /* For each cell, examine a 3x3 "window" of cells around it,
                 * and count the number of live (true) cells in the window. */
            for (int y_offset = -1; y_offset <= 1; ++y_offset) 
            {
                for (int x_offset = -1; x_offset <= 1; ++x_offset) 
                {
                    if (state->at(x + x_offset, y + y_offset)) 
                    {
                        ++live_in_window;
                    }
                }
            }
            next_state->at(x, y) = (
                live_in_window == 3 /* dead cell with 3 neighbors or live cell with 2 */ 
                ||
                (live_in_window == 4 && state->at(x, y)) /* live cell with 3 neighbors */
            );
        }    
    }
}