#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h> 
#include <stdlib.h>
#include <errno.h>  
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;


class Cmd
{
    // Access specifier                                                         
    public:
    vector<string> cmdVec;
    Cmd()
    {
      cmdVec = vector<string>();
    }
    
};


class CmdPipe
{
    // Access specifier                                                         
    public:
    // Data Members                                                             
    string pipeStr;
	string inputFile;
	string outputFile;
    vector<Cmd> pipeVec;
    CmdPipe()
    {
      pipeStr = "";
      pipeVec = vector<Cmd>();
	  this->inputFile = "";
	  this->outputFile = "";
    }
};



void processToken(string &token,CmdPipe &cmdPipe, Cmd &cmd)
{
  
  // token += "test";
  cmd.cmdVec.push_back(token);
  //cout << token << endl;
}

void parse_and_run_command(const string &command) 
{
    /* TODO: Implement this. */
    /* Note that this is not the correct way to test for the exit command.
       For example the command "   exit  " should also exit your shell.
     */
	bool inputFlag = false; 
	bool outFlag = false;  
	
	 
    CmdPipe cmdPipe = CmdPipe();
    Cmd cmd = Cmd();
    string token;
	string tempFileName;
    istringstream s(command);
    while (s >> token) 
	{
        if (token == ">")
        {
			s >> tempFileName;
			if (tempFileName == "" || tempFileName == "<" || tempFileName == ">" || tempFileName == "|")
			{
				cerr << "invalid command" << endl;
				return;
				//exit(1);
			}
			cmdPipe.outputFile = tempFileName;
			if (outFlag == false)
			{
				outFlag = true;
			}
			else
			{
				cerr << "invalid command" << endl;
				return;
			}			
		}
		else if (token == "<")
		{
			s >> tempFileName;
			if (tempFileName == "" || tempFileName == "<" || tempFileName == ">" || tempFileName == "|")
			{
				cerr << "invalid command" << endl;
				return;
				//exit(2);
			}
			cmdPipe.inputFile = tempFileName;
			if (inputFlag == false)
			{
				inputFlag = true;
			}
			else
			{
				cerr << "invalid command" << endl;
				return;				
			}
		}
		else if (token == "|")
		{
			s >> tempFileName;
			if (tempFileName == "" || tempFileName == "<" || tempFileName == ">" || tempFileName == "|")
			{
				cerr << "invalid command" << endl;
				return;
				//exit(2);
			}
			cmdPipe.pipeVec.push_back(cmd);
			cmd.cmdVec.clear();
			processToken(tempFileName, cmdPipe, cmd);
		}
		else
		{
			processToken(token, cmdPipe, cmd);
		}
    }
	cmdPipe.pipeVec.push_back(cmd); 
    
/* 	for (Cmd _cmd : cmdPipe.pipeVec)
	{
		for(string _s: _cmd.cmdVec)
		{
			cout << _s << " cmd size " << _cmd.cmdVec.size() <<
			" # of cmds " << cmdPipe.pipeVec.size() << endl;
		}
		cout << endl;
	}  */
	int read_fd = -1;
	int write_fd = -1;
	

  
    vector<pid_t> pidVec = vector<pid_t>();
    for(int i = 0; i < (int) cmdPipe.pipeVec.size(); i++) 
    {
		Cmd& curCmd = cmdPipe.pipeVec.at(i);
		if (curCmd.cmdVec.size() == 0)
		{
			cerr << "invalid command" << endl;
			return;
		}
		bool only = cmdPipe.pipeVec.size() == 1;
		bool first = i == 0;
		bool last = i == (int)cmdPipe.pipeVec.size()-1;
		bool middle = !first && !last && !only;
		string cmdStr = curCmd.cmdVec.front();
		//cout << cmdStr << first << middle << last << endl;
		if (cmdStr == "exit")
		{
			exit(0);
		}
		if (first)
		{
			read_fd = -1;
			write_fd = -1;
		}

		int pipe_fd[2];
		//pipe_fd[0] = -1;
		//pipe_fd[1] = -1;
		if (first && !only) // or middle?
		{
			if(pipe(pipe_fd) < 0)
			{
				cerr << "invalid command" << endl;
				return;
			}
			/*normalcase:*/
			read_fd = pipe_fd[0];
			write_fd = pipe_fd[1];
		}
		if (middle) // or middle?
		{
			if(pipe(pipe_fd) < 0)
			{
				cerr << "invalid command" << endl;
				return;
			}
			//cout << read_fd << " " << pipe_fd[0] << " " << pipe_fd[1] << endl;			
			/*normalcase:*/
			//read_fd = pipe_fd[0];
			//write_fd = pipe_fd[1];
		}
		string commandTemp;
		pid_t pid = fork();
		if (pid == 0)
		{	
			//cout << cmdStr << ": start fork " << "read_fd: " << read_fd << " write_fd: " << write_fd << endl;
			string tempSH = "";
			if (first && !only && write_fd != -1) // if not last, set the out to next command
			{ // first pass
				//cout << cmdStr << ": set output"<< endl;
				dup2(pipe_fd[1], STDOUT_FILENO);
				close(pipe_fd[0]); 
				close(pipe_fd[1]);
				read_fd = -1;
				write_fd = -1;
			}
			if (last && !only && read_fd != -1) // if not first, set the input to pervious command
			{
				//cout << cmdStr << ": set input" << endl;
				dup2(pipe_fd[0], STDIN_FILENO);
				close(pipe_fd[0]); 
				close(pipe_fd[1]);
				read_fd = -1;
				write_fd = -1;
			}
			if (middle) // if not first, set the input to pervious command
			{
/* 				if( read_fd == -1)
					cout << "closed read" << endl;
				if( write_fd != -1)
					cout << "open write" << endl; */
				// set close read
				dup2(read_fd, STDIN_FILENO);
				close(read_fd); 
				dup2(pipe_fd[1], STDOUT_FILENO);
				close(pipe_fd[1]);
				write_fd = -1;
				close(pipe_fd[0]);
				//cout << read_fd << " " << write_fd << endl;
				
			}
			if(cmdPipe.outputFile != "" && i == (int) cmdPipe.pipeVec.size()-1)
			{
				const char * txt_read = cmdPipe.outputFile.c_str();
				int fd = open(txt_read, O_WRONLY|O_CREAT|O_TRUNC, 0666);
				if (fd == -1)
				{
					cerr << "invalid command" << endl;
					exit(5);
				}
				else
				{
					dup2(fd, STDOUT_FILENO);
				}
				close(fd);
			}
			if( cmdPipe.inputFile != "" && i == 0)
			{
				const char * txt_read = cmdPipe.inputFile.c_str();
				int fd = open(txt_read, O_RDWR);

				if (fd == -1)
				{
					cerr << "invalid command" << endl;
					exit(6);
				}
				else
				{
					dup2(fd, STDIN_FILENO);
				}
				close(fd);
			}
			const char **argv = new const char* [curCmd.cmdVec.size()+1];
			for (int j = 0;  j < (int) curCmd.cmdVec.size();  j++)
			{// copy args
				argv [j] = const_cast<char*>(curCmd.cmdVec.at(j).c_str());
			}
			argv[curCmd.cmdVec.size()] = NULL;
			commandTemp =  cmdStr;
			const char* commandExec = commandTemp.c_str();
			//cout << cmdStr << ": exec" << endl;
			execv(commandExec, (char **)argv);
			perror("");
			exit(7);
		}
		else if (pid > 0)
		{
			// close(pipe_fd[0]); 
			// close(pipe_fd[1]);
			//cout << cmdStr << ": close pipe" << endl;
			if(first && !only)
			{
				//close(pipe_fd[0]); 
				close(pipe_fd[1]);
				//read_fd = -1;
				write_fd = -1;
				pipe_fd[1] = write_fd;

			}
			if(middle)
			{
				close(read_fd); 
				read_fd = pipe_fd[0];
				close(pipe_fd[1]); 
				//close(pipe_fd[1]);
				write_fd = -1;
				pipe_fd[1] = -1;
			}
			if(last && !only)
			{
				close(pipe_fd[0]); 
				//close(pipe_fd[1]);
				read_fd = -1;
				pipe_fd[0] = read_fd;
				//write_fd = -1;
			}
			pidVec.push_back(pid);
		}
		else
		{
			cerr << "exit status 255" << endl;
		}
	
	}

    vector<int> statusVec = vector<int>();
    for (int i = 0; i < (int) pidVec.size(); i++)
    {
        pid_t pid = pidVec.at(i);
		int status;
        waitpid(pid, &status,0);
		string commandName = cmdPipe.pipeVec.at(i).cmdVec.front();
		if(commandName == "exit")
		{
			exit(0);
		}
		else if (WIFEXITED(status))
		{
			printf("%s exit status: %d\n", commandName.c_str(),
			WEXITSTATUS(status));
	
		}
		else if(WIFSIGNALED(status))
		{
			printf("%s killed by signal %d\n", commandName.c_str(),
			WTERMSIG(status));
		}
		else
		{
		}
	}		
}


int main(void) {
    string command;
    cout << "> ";
    while (getline(cin, command)) {

        parse_and_run_command(command);
        cout << "> ";
    }
    return 0;
}


// this is modified
