#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "traps.h"
#include "spinlock.h"

// Interrupt descriptor table (shared by all CPUs).
struct gatedesc idt[256];
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
struct spinlock tickslock;
uint ticks;

int allocOnDem(struct proc* proccess, uint add);
int mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm);
int addresOK(struct proc* proccess, uint address);

int cowFaultHandle(struct proc * proccess, pte_t * pte);

int proc_getpagetableentry(int pid, int address);
int kalloc_isphysicalpagefree(int ppn);
int proc_dumppagetable(int pid);

void
tvinit(void)
{
  int i;

  for(i = 0; i < 256; i++)
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
}

void
idtinit(void)
{
  lidt(idt, sizeof(idt));
}

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
  uint address;
  if(tf->trapno == T_SYSCALL){
    if(myproc()->killed)
      exit();
    myproc()->tf = tf;
    syscall();
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
      acquire(&tickslock);
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_COM1:
    uartintr();
    lapiceoi();
    break;
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
            cpuid(), tf->cs, tf->eip);
    lapiceoi();
    break;
  case T_PGFLT:
    struct proc* process = myproc();
    address = rcr2();
    // check that address isn't access to kernel or 
    //cprintf("Add: %x\n", address);

    pde_t* pgtab = process->pgdir;
    pte_t* pte = walkpgdir(pgtab, (void *) address, 0);

    //proc_dumppagetable(process->pid);    

    if( (*pte & PTE_P) && (*pte & PTE_U) && !(*pte & PTE_W) )
    {
      //cprintf("Cow \n");
      cowFaultHandle(process, pte);
      break;
    }

    if (addresOK(process, address) == 1)
    {
        allocOnDem(process, address);
        break;
    }
    cprintf("Address: %x \n", address);
    //cprintf("PTE: %x \n", pte);
    //proc_dumppagetable(process->pid);
    
    if(myproc() == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
    break;
  //PAGEBREAK: 13
  default:


    if(myproc() == 0 || (tf->cs&3) == 0)
    {
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();
}


void inc_ref_cnt(uint pa);
void dec_ref_cnt(uint pa);
char get_ref_cnt(uint pa);


int
cowFaultHandle(struct proc * proccess, pte_t * pte) //struct proc* proccess, uint add
{
  // ref count gt 1

  uint pa_og = PTE_ADDR(*pte);
  int ref_cnt = get_ref_cnt(pa_og);
  if(ref_cnt > 1)
  {
    char * mem = kalloc();
    
    int pa_new = V2P(mem);
    if(get_ref_cnt(pa_new)!= 1)
    {
      cprintf("Kalloc not return 1\n");
      return 0;
    }

    if( mem == 0 ) 
    {
      cprintf("Page fault out of memory, kill proc %s with pid %d\n", proccess->name, proccess->pid);
      proccess->killed = 1;
      return 0;
    }
    // check from 

          // copy the contents from the original memory page pointed the virtual address
    memmove(mem, (char*)P2V(pa_og), PGSIZE);
          // point the given page table entry to the new page 
    *pte = V2P(mem) | PTE_P | PTE_U | PTE_W;

        // Since the current process now doesn't point to original page, 
        // decrement the reference count by 1
      //decrementReferenceCount(pa);
  }
  else if(ref_cnt == 1)
  {
      // remove the read-only restriction on the trapping page
      *pte |= PTE_W;
  }
  else
  {
    //cprintf("cow access to ref count 0?");
    //return 0;
  }
  return 1;
}

int 
addresOK(struct proc* proccess, uint address) // make system calls that attempt to read or write to not-yet-allocated parts of the heap work.
{
  pte_t* pte;
  pte = walkpgdir(proccess->pgdir, (char*) address, 0);


  if( (*pte & PTE_P) && !(*pte & PTE_U) ) // gaurd page, 
  {
    cprintf("Gaurd page access\n");
    return 0;
  }
  // if( (*pte & PTE_P))
  // {
  //   cprintf("Access to already allocated \n");
  //   return 0;
  // }
  if(address >= KERNBASE)
  {
    cprintf("pte: %x", pte);
    cprintf("Address in kernel space \n");
    return 0;
  }
  if(address >= proccess->sz) //kill a process when it attempts to access memory outside of its allocation,
  {
    cprintf("Address greater than size \n");
    return 0;
  }

  return 1;
}



int
allocOnDem(struct proc* proccess, uint add)
{
  char *mem;
  uint a;
  pde_t *pgdir = proccess->pgdir;
  uint oldsz = proccess->sz;
  uint newsz = oldsz + PGSIZE;
  //uint n = PGSIZE;
  
  if(add >= KERNBASE)
  {
    cprintf("Address in kernel space \n");
    return 0;
  }

  a = PGROUNDDOWN(add);
  //cprintf("Address: %x\n", a);
  //cprintf("Size: %d\n", proccess->sz);
  mem = kalloc(); 


  if(mem == 0){ // requiring an allocation on demand and no more memory
    cprintf("allocuvm out of memory\n");
    deallocuvm(pgdir, newsz, oldsz); //
    proccess->killed = 1; // kill proccess
    return 0;
  }
  memset(mem, 0, PGSIZE); // allocates memory to 0
  int i = mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U); // mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm


  // it should not allocate a table entry that has already been allocate under
  // use walk pgdir to get pte, then check present flag, don't allocate

  if(i < 0){
    cprintf("allocuvm out of memory (2)\n");
    deallocuvm(pgdir, newsz, oldsz);
    kfree(mem);
    proccess->killed = 1;
    return 0;
  
  }
  
  lcr3(V2P(pgdir));
  return newsz;
}



//Must make system calls that attempt to read or write to not-yet-allocated parts of the heap work. 
//For example, malloc()ing a very large buffer, then using read() to fill it must work. 
//We do not care, however, what happens if the process runs out of memory during such a system call and must be killed. 
//(For the most part, this should just require treating page faults triggered by the kernel the same as page faults triggered from user mode.)