#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "traps.h"
#include "spinlock.h"

// Interrupt descriptor table (shared by all CPUs).
struct gatedesc idt[256];
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
struct spinlock tickslock;
uint ticks;

int allocOnDem(struct proc* proccess, uint add);
int mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm);
int addresOK(struct proc* proccess, uint address);

void
tvinit(void)
{
  int i;

  for(i = 0; i < 256; i++)
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
}

void
idtinit(void)
{
  lidt(idt, sizeof(idt));
}

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
  if(tf->trapno == T_SYSCALL){
    if(myproc()->killed)
      exit();
    myproc()->tf = tf;
    syscall();
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
      acquire(&tickslock);
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_COM1:
    uartintr();
    lapiceoi();
    break;
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
            cpuid(), tf->cs, tf->eip);
    lapiceoi();
    break;
  case T_PGFLT:
    uint address = rcr2();
    // check that address isn't access to kernel or 
    if (addresOK(myproc(), address) == 1)
    {
        allocOnDem(myproc(), address);
        break;
    }
    if(myproc() == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
    break;
  //PAGEBREAK: 13
  default:
    if(myproc() == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();
}


int 
addresOK(struct proc* proccess, uint address) // make system calls that attempt to read or write to not-yet-allocated parts of the heap work.
{
  pte_t* pte;
  pte = walkpgdir(proccess->pgdir, (char*) address, 0);

  if( (*pte & PTE_P) && !(*pte & PTE_U) ) // gaurd page, 
  {
    cprintf("Gaurd page access\n");
    return 0;
  }
  if(address >= KERNBASE)
  {
    cprintf("Address in kernel space \n");
    return 0;
  }
  if(address >= proccess->sz) //kill a process when it attempts to access memory outside of its allocation,
  {
    cprintf("Address greater than size \n");
    return 0;
  }

  return 1;
}

int
allocOnDem(struct proc* proccess, uint add)
{
  char *mem;
  uint a;
  pde_t *pgdir = proccess->pgdir;
  uint oldsz = proccess->sz ;
  uint newsz = oldsz + PGSIZE;

  if(add >= KERNBASE)
  {
    cprintf("Address in kernel space \n");
    return 0;
  }

  a = PGROUNDUP(add);
  mem = kalloc();
  if(mem == 0){ // requiring an allocation on demand and no more memory
    cprintf("allocuvm out of memory\n");
    deallocuvm(pgdir, newsz, oldsz); //deallocuvm(curproc->pgdir, sz, sz + n)
    proccess->killed = 1; // kill proccess
    return 0;
  }
  memset(mem, 0, PGSIZE); // allocates memory to 0
  int i = mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U); // mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm)
  if(i < 0){
    cprintf("allocuvm out of memory (2)\n");
    deallocuvm(pgdir, newsz, oldsz);
    kfree(mem);
    proccess->killed = 1;
    return 0;
  
  }
  lcr3(V2P(myproc()->pgdir));
  return newsz;
}

//Must make system calls that attempt to read or write to not-yet-allocated parts of the heap work. 
//For example, malloc()ing a very large buffer, then using read() to fill it must work. 
//We do not care, however, what happens if the process runs out of memory during such a system call and must be killed. 
//(For the most part, this should just require treating page faults triggered by the kernel the same as page faults triggered from user mode.)